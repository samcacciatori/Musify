package org.musify.models;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

import org.springframework.transaction.annotation.Transactional;

@Transactional
@Entity
public class Artist {
	
	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	private String name;
	private int year;

	@OneToMany(mappedBy = "artist", fetch = FetchType.EAGER)
	private List<People> members = new ArrayList<>();
	
	@ManyToMany(fetch = FetchType.EAGER)
	private List<Style> styles = new ArrayList<>();
	
	public List<People> getMembers() {
		return members;
	}
	public void setMembers(List<People> members) {
		this.members = members;
	}
	public List<Style> getStyles() {
		return styles;
	}
	public void setStyles(List<Style> styles) {
		this.styles = styles;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	
	public int getYearArtist() {
		return this.year;
	}
	@Override
	public String toString() {
		return "Artista [id=" + id + ", year=" + year + ", members=" + members + ", name=" + name + "]";
	}

}
