package org.musify.models;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

import org.springframework.transaction.annotation.Transactional;

@Transactional
@Entity
public class Style {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	private String name;

	@ManyToMany(mappedBy="styles", fetch=FetchType.EAGER)
	private List<Artist> artists = new ArrayList<>();

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id ;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Artist> getArtists() {
		return artists;
	}

	public void setArtists(List<Artist> artists) {
		this.artists = artists;
	}
	
	

	@Override
	public String toString() {
		//return "Style [id=" + id + ", name=" + name + "]";
		return "Style [id=" + id + ", name=" + name + ", artists=" + artists + "]";
	}
	
}
