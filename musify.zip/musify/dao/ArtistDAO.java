package org.musify.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.musify.models.Artist;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
@Transactional
public class ArtistDAO {

	@PersistenceContext
	private EntityManager manager;

	public void gravar(Artist artista) {
		manager.persist(artista);
	}

	public List<Artist> getArtistas() {
		return manager.createQuery("select a from Artist a", Artist.class)
				.getResultList();
	}
}
