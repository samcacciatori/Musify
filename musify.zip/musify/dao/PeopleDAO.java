package org.musify.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.musify.models.People;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
@Transactional
public class PeopleDAO {
	
	@PersistenceContext
	private EntityManager manager;
	
	public void gravar(People people) { 
		manager.persist(people);
	}
	
	public List<People> getPeopleList() {
		return manager.createQuery("select p from People p", People.class).getResultList();
	}

	public void delete(People people) {
		manager.remove(people);
	}

	public People findById(long id) {
		return manager.find(People.class, id);
	}

}
