package org.musify.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import org.musify.models.Style;

@Repository
@Transactional
public class StyleDAO {

	@PersistenceContext
	private EntityManager manager;

	public void gravar(Style style) {
		manager.persist(style);
	}
	
	public List<Style> getStyleList() {
		return manager.createQuery("select s from Style s", Style.class).getResultList();
	}

	public void delete(Style style) {
		manager.remove(style);
	}

	public Style findById(long id) {
		return manager.find(Style.class, id);
	}

}
