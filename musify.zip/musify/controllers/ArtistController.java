package org.musify.controllers;

import java.util.List;

import org.musify.dao.ArtistDAO;
import org.musify.dao.PeopleDAO;
import org.musify.dao.StyleDAO;
import org.musify.models.Artist;
import org.musify.models.People;
import org.musify.models.Style;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/artist")
public class ArtistController {

	@Autowired
	private ArtistDAO dao;

	@Autowired
	private PeopleDAO peopleDao;

	@Autowired
	private StyleDAO styleDao;

	@RequestMapping(value = "/form", method = RequestMethod.GET)
	public ModelAndView form() {
		List<Artist> artists = dao.getArtistas();
		List<People> peopleList = peopleDao.getPeopleList();
		List<Style> styles = styleDao.getStyleList();

		ModelAndView modelAndView = new ModelAndView("artist/form");
		modelAndView.addObject("artists", artists);
		modelAndView.addObject("peopleList", peopleList);
		modelAndView.addObject("styles", styles);
		System.out.println(artists);
		System.out.println(peopleList);
		System.out.println(styles);

		return modelAndView;
	}

	@RequestMapping(method = RequestMethod.POST)
	public ModelAndView gravar(Artist artista) {
		System.out.println(artista);
		dao.gravar(artista);

		return new ModelAndView("redirect:artist/form");
	}
}