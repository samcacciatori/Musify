package org.musify.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;

@Transactional
@Controller
public class HomeController {

	
	@RequestMapping("/")
	public String index()
	{
		System.out.println("Entrando em mi arquivo de musicas");
		return "home";
	}
}
