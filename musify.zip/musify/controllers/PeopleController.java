package org.musify.controllers;

import org.musify.dao.PeopleDAO;
import org.musify.models.People;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/people")
public class PeopleController {
	
	@Autowired
	private PeopleDAO dao;

	@RequestMapping(method = RequestMethod.POST)
	public ModelAndView cadastra(People people) {
		dao.gravar(people);
		ModelAndView view = new ModelAndView("redirect:artist/form");
		
		return view;
	}
	
	@RequestMapping(value="delete/{id}", method=RequestMethod.POST)
	public ModelAndView deletePeople(@PathVariable("id") long id) {
		People people = dao.findById(id);
		System.out.println(people);
		dao.delete(people);
		
		return new ModelAndView("redirect:artist/form");
	}
	
}
