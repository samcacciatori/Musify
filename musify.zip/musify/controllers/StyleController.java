package org.musify.controllers;

import org.musify.dao.StyleDAO;
import org.musify.models.Style;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/style")
public class StyleController {
	
	@Autowired
	private StyleDAO dao;

	@RequestMapping(method = RequestMethod.POST)
	public ModelAndView cadastra(Style style) {
		dao.gravar(style);
		ModelAndView view = new ModelAndView("redirect:artist/form");
		
		return view;
	}
	
	@RequestMapping(value="delete/{id}", method=RequestMethod.POST)
	public ModelAndView deleteStyle(@PathVariable("id") long id) {
		Style style = dao.findById(id);
		System.out.println(style);
		dao.delete(style);
		
		return new ModelAndView("redirect:artist/form");
	}
	
}
